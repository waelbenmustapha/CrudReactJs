import 'bootstrap/dist/css/bootstrap.min.css';

import logo from './logo.svg';
import './App.css';
import Book from './Views/Book';

function App() {
  return (
    <div className="App">
    <Book/>
    </div>
  );
}

export default App;
