import React from 'react'
import { deletedbook } from '../Service/BookService'

function ListeBook(props) {
  return (
    <div>
        
<table>
<tr><th>nom</th>
<th>acteur</th>
<th>category</th>
<th>edit</th>
<th>delete</th></tr>
{props.books.map((el)=><tr>
<td>{el.nom}</td> 
<td>{el.acteur}</td> 
<td>{el.category}</td> 
<td className='hover' onClick={()=>{props.setidtoupdate(el.id);props.setshow(true)}}>edit</td> 
<td className='hover' onClick={()=>deletedbook(props.books,props.setbooks,el.id)}>Delete</td> 
</tr>)}

</table>


    </div>
  )
}

export default ListeBook